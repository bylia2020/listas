#!/bin/sh
rm /etc/enigma2/lista.zip
rm -R /etc/enigma2/lista/
cd /etc/enigma2/
wget https://app.box.com/s/e3kiefoom6jyuixnpbyclxjit35oc64z/folder/687426924771
unzip lista.zip
cp lista/*.tv /etc/enigma2/
cp lista/lamedb /etc/enigma2/
cp lista/*.xml /etc/tuxbox/
cp lista/downloadLdC.sh /etc/init.d/
cd /etc/enigma2/
rm lista.zip
rm -R lista/
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0